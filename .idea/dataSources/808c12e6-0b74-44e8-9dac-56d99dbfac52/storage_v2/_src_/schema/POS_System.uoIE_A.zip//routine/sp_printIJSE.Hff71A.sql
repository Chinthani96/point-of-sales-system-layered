create
  definer = root@localhost procedure sp_printIJSE()
BEGIN
  DECLARE X VARCHAR(4);
  SET X = 'IJSE';
  SELECT X;
end;

